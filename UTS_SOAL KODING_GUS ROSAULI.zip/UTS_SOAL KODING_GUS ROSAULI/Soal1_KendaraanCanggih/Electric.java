// Electric.java
// Ini adalah interface yang mendefinisikan kontrak untuk kendaraan yang bisa diisi daya listrik.
// Interface hanya berisi deklarasi method (abstrak secara implisit), tidak ada implementasi.
public interface Electric {
    // Method untuk mengisi daya baterai.
    // Class yang mengimplementasikan interface ini WAJIB menyediakan logika untuk mengisi daya.
    void chargeBattery();
}