// Vehicle.java
// Ini adalah class abstrak yang mendefinisikan konsep dasar sebuah kendaraan.
// Class abstrak tidak bisa di-instantiate langsung, tapi berfungsi sebagai blueprint.
public abstract class Vehicle {
    // Atribut umum untuk semua kendaraan
    protected String brand; // protected agar bisa diakses oleh subclass
    protected String model;

    // Konstruktor untuk inisialisasi brand dan model
    public Vehicle(String brand, String model) {
        this.brand = brand;
        this.model = model;
        System.out.println("Vehicle '" + brand + " " + model + "' sedang dirakit...");
    }

    // Method abstrak: Setiap kendaraan harus punya cara untuk "menyalakan mesin".
    // Namun, implementasinya akan berbeda untuk setiap jenis kendaraan (Car, Motorcycle).
    // Method abstrak tidak punya body, hanya deklarasi.
    public abstract void startEngine();

    // Method non-abstrak: Perilaku umum yang dimiliki semua kendaraan
    public void stopEngine() {
        System.out.println(brand + " " + model + " mesinnya mati.");
    }

    public void displayInfo() {
        System.out.println("--- Informasi Kendaraan ---");
        System.out.println("Brand: " + brand);
        System.out.println("Model: " + model);
    }
}