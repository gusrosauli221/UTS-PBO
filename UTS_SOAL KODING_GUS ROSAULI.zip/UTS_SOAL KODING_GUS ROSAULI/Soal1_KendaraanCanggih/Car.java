// Car.java
// Class Car mewarisi sifat dari Vehicle dan mengimplementasikan interface Electric.
public class Car extends Vehicle implements Electric {
    private int numberOfDoors; // Atribut spesifik untuk mobil

    // Konstruktor untuk Car, memanggil konstruktor superclass Vehicle
    public Car(String brand, String model, int numberOfDoors) {
        // Constructor Chaining: memanggil konstruktor Vehicle (superclass)
        super(brand, model); 
        this.numberOfDoors = numberOfDoors;
        System.out.println("Mobil " + brand + " " + model + " siap digunakan.");
    }

    // Override method startEngine() dari Vehicle (WAJIB diimplementasikan karena abstrak)
    @Override
    public void startEngine() {
        System.out.println("🚘 " + brand + " " + model + " menyala! Mode standar aktif. Siap melaju dengan " + numberOfDoors + " pintu.");
    }

    // Implementasi method chargeBattery() dari interface Electric (WAJIB diimplementasikan)
    @Override
    public void chargeBattery() {
        System.out.println("⚡️ " + brand + " " + model + " sedang mengisi daya baterai di stasiun pengisian. Estimasi 30 menit.");
    }

    // Method spesifik Car (opsional)
    public void activateTurbo() {
        System.out.println("🚀 " + brand + " " + model + " Turbo mode ON! Vrooom!");
    }

    // Override displayInfo untuk menambahkan info spesifik Car
    @Override
    public void displayInfo() {
        super.displayInfo(); // Panggil method dari superclass
        System.out.println("Tipe  : Mobil");
        System.out.println("Pintu : " + numberOfDoors);
    }
}