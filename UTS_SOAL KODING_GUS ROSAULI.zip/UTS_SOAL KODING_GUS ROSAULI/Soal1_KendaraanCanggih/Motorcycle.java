// Motorcycle.java
// Class Motorcycle mewarisi sifat dari Vehicle.
public class Motorcycle extends Vehicle {
    private boolean hasSidecar; // Atribut spesifik untuk motor

    // Konstruktor untuk Motorcycle, memanggil konstruktor superclass Vehicle
    public Motorcycle(String brand, String model, boolean hasSidecar) {
        // Constructor Chaining: memanggil konstruktor Vehicle (superclass)
        super(brand, model);
        this.hasSidecar = hasSidecar;
        System.out.println("Motor " + brand + " " + model + " siap digeber.");
    }

    // Override method startEngine() dari Vehicle (WAJIB diimplementasikan karena abstrak)
    @Override
    public void startEngine() {
        String sidecarStatus = hasSidecar ? "dengan sespan" : "tanpa sespan";
        System.out.println("🏍️ " + brand + " " + model + " dihidupkan! Suara knalpot menggelegar " + sidecarStatus + ".");
    }

    // Method spesifik Motorcycle (opsional)
    public void doWheelie() {
        System.out.println("🤸‍♂️ " + brand + " " + model + " sedang melakukan wheelie yang keren!");
    }

    // Override displayInfo untuk menambahkan info spesifik Motorcycle
    @Override
    public void displayInfo() {
        super.displayInfo(); // Panggil method dari superclass
        System.out.println("Tipe  : Motor");
        System.out.println("Sespan: " + (hasSidecar ? "Ada" : "Tidak Ada"));
    }
}