// MainApp.java
// Class utama untuk mendemonstrasikan polymorphism dan penggunaan class/interface.
public class MainApp {
    public static void main(String[] args) {
        System.out.println("=== Simulasi Parkiran Kendaraan Canggih ===");
        System.out.println("------------------------------------------\n");

        // --- Demonstrasi Polymorphism (Vehicle) ---
        // Membuat objek Car dan Motorcycle, tapi direferensikan sebagai Vehicle.
        // Ini menunjukkan bahwa objek Car dan Motorcycle adalah jenis dari Vehicle.
        Vehicle myCar = new Car("Tesla", "Model S", 4);
        Vehicle myMotorcycle = new Motorcycle("Harley-Davidson", "Iron 883", false);
        Vehicle futuristicCar = new Car("CyberTron", "X-200", 2); // Mobil masa depan 2 pintu

        System.out.println("\n--- Proses Penyalakan Mesin Otomatis ---");
        // Memanggil startEngine() pada referensi Vehicle.
        // Meskipun tipe referensinya sama (Vehicle), implementasi yang dipanggil akan berbeda
        // sesuai dengan tipe objek sebenarnya (Car atau Motorcycle). Ini adalah Polymorphism.
        myCar.startEngine();        // Memanggil startEngine() milik Car
        myMotorcycle.startEngine(); // Memanggil startEngine() milik Motorcycle
        futuristicCar.startEngine(); // Memanggil startEngine() milik Car (lagi)

        System.out.println("\n--- Menampilkan Informasi Kendaraan ---");
        myCar.displayInfo();
        System.out.println("------------------------------------------");
        myMotorcycle.displayInfo();
        System.out.println("------------------------------------------");
        futuristicCar.displayInfo();
        System.out.println("------------------------------------------");


        // --- Demonstrasi Interface (Electric) ---
        // Objek Car juga bisa direferensikan sebagai Electric karena ia mengimplementasikannya.
        // Objek Motorcycle TIDAK bisa direferensikan sebagai Electric.
        System.out.println("\n--- Mengisi Daya Kendaraan Listrik ---");
        // Hanya objek yang mengimplementasikan Electric yang bisa memanggil chargeBattery()
        
        // Cek apakah kendaraan adalah Electric
        if (myCar instanceof Electric) { // Pengecekan runtime type (instanceof)
            Electric electricCar = (Electric) myCar; // Casting ke interface Electric
            electricCar.chargeBattery();
        }

        if (futuristicCar instanceof Electric) {
             Electric futuristicElectricCar = (Electric) futuristicCar;
             futuristicElectricCar.chargeBattery();
        }


        // --- Memanggil Method Spesifik Subclass ---
        System.out.println("\n--- Aksi Spesifik Kendaraan ---");
        // Untuk memanggil method spesifik subclass, kita perlu cast ke tipe subclass tersebut.
        // Ini menunjukkan bahwa objek masih mempertahankan perilaku aslinya.
        if (myCar instanceof Car) {
            Car actualCar = (Car) myCar;
            actualCar.activateTurbo();
        }

        if (myMotorcycle instanceof Motorcycle) {
            Motorcycle actualMotorcycle = (Motorcycle) myMotorcycle;
            actualMotorcycle.doWheelie();
        }
        
        System.out.println("\n------------------------------------------");
        System.out.println("=== Simulasi Selesai. Selamat Berkendara! ===");
    }
}