// MainApp.java
// Class utama untuk mendemonstrasikan sistem karakter RPG.
public class MainApp {
    public static void main(String[] args) {
        System.out.println("=== RPG ADVENTURE: THE SEALED LEGEND ===");
        System.out.println("----------------------------------------\n");

        // --- PEMBUATAN KARAKTER ---
        // Membuat objek dari subclass Character (Polymorphism)
        Character player1 = new Warrior("Kael", 200, 25, 15);
        Character player2 = new Mage("Lyra", 150, 30, 80);

        // Membuat Legendary Knight (HANYA BISA SATU INSTANSI - Singleton)
        // Kita tidak bisa langsung 'new LegendaryKnight(...)', harus pakai getInstance()
        LegendaryKnight legend = LegendaryKnight.getInstance();
        
        // Coba membuat Legendary Knight kedua (akan mengembalikan instance yang sama)
        LegendaryKnight legend2 = LegendaryKnight.getInstance();
        System.out.println("\nApakah legend dan legend2 objek yang sama? " + (legend == legend2)); // Output: true

        System.out.println("\n--- ARENA PERTEMPURAN DIMULAI! ---");
        System.out.println("-----------------------------------\n");

        // --- Demonstrasi Polymorphism & Method Overriding ---
        System.out.println("Giliran " + player1.getName() + "!");
        player1.displayStats();
        player1.performAttack(player2); // Warrior menyerang Mage

        System.out.println("\nGiliran " + player2.getName() + "!");
        player2.displayStats();
        player2.performAttack(player1); // Mage menyerang Warrior

        System.out.println("\nGiliran " + legend.getName() + "!");
        legend.displayStats();
        legend.performAttack(player1); // Legendary Knight menyerang Warrior

        System.out.println("\n--- PENGGUNAAN SKILL UNIK ---");
        // Menggunakan Skill Interface melalui casting dan instanceof
        if (player1 instanceof Skill) {
            Skill warriorSkill = (Skill) player1;
            warriorSkill.activateSkill(null); // Skill Warrior biasanya self-buff
        }

        if (player2 instanceof Skill) {
            Skill mageSkill = (Skill) player2;
            mageSkill.activateSkill(player1); // Skill Mage menyerang target
        }
        
        if (legend instanceof Skill) {
            Skill legendSkill = (Skill) legend;
            legendSkill.activateSkill(player2); // Skill Legendary Knight menyerang target
        }

        System.out.println("\n--- ULTIMATE MOVE ---");
        // Memanggil method spesifik dari LegendaryHero
        if (legend instanceof LegendaryHero) {
            LegendaryHero legendaryHero = (LegendaryHero) legend;
            legendaryHero.unleashUltimate(player2); // Ultimate Legendary Knight
        }

        System.out.println("\n--- STATUS AKHIR PERTEMPURAN ---");
        player1.displayStats();
        player2.displayStats();
        legend.displayStats();

        System.out.println("\n----------------------------------------");
        System.out.println("=== PETUALANGAN BERAKHIR. GOOD GAME! ===");
    }
}
