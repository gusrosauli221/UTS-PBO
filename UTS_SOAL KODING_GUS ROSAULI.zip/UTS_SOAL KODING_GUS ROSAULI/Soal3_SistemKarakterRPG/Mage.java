// Mage.java
// Class Mage, mewarisi Character dan mengimplementasikan Skill.
public non-sealed class Mage extends Character implements Skill {
    private int mana; // Atribut spesifik Mage

    public Mage(String name, int health, int attackPower, int mana) {
        super(name, health, attackPower); // Constructor Chaining
        this.mana = mana;
    }

    @Override
    public void performAttack(Character target) {
        int damage = attackPower + (mana / 5); // Damage disesuaikan dengan mana
        System.out.println("🔥 " + name + " meluncurkan Bola Api sihir ke " + target.getName() + "!");
        target.takeDamage(damage);
    }

    @Override
    public void activateSkill(Character target) {
        if (mana >= 20) {
            System.out.println("🔮 " + name + " mengaktifkan skill 'Arcane Blast' ke " + target.getName() + "! Damage besar!");
            target.takeDamage(attackPower * 2); // Skill damage lebih besar
            this.mana -= 20;
            System.out.println("Mana " + name + " tersisa: " + this.mana);
        } else {
            System.out.println("Mana " + name + " tidak cukup untuk Arcane Blast!");
        }
    }

    @Override
    public void displayStats() {
        System.out.println("--- Status Mage ---");
        System.out.println("Nama   : " + name);
        System.out.println("HP     : " + health);
        System.out.println("ATK    : " + attackPower);
        System.out.println("Mana   : " + mana);
    }
}