// Character.java
// Ini adalah class abstrak yang menjadi fondasi untuk semua karakter dalam game.
// Mendefinisikan atribut dan perilaku dasar yang harus dimiliki setiap karakter.
// Dibuat SEALED untuk mendukung non-sealed subclasses (Warrior, Mage).
public abstract sealed class Character
    permits Warrior, Mage, LegendaryHero { // <-- TAMBAHKAN INI

    protected String name;
    protected int health;
    protected int attackPower;

    // Konstruktor untuk inisialisasi karakter dasar
    public Character(String name, int health, int attackPower) {
        this.name = name;
        this.health = health;
        this.attackPower = attackPower;
        System.out.println("✨ Karakter '" + name + "' diciptakan!");
    }

    // Method abstrak: Setiap karakter harus punya cara menyerang.
    // Implementasi spesifik akan ada di subclass.
    public abstract void performAttack(Character target);

    // Method abstrak: Setiap karakter harus bisa menampilkan statusnya.
    public abstract void displayStats();

    // Getter (opsional, tapi bagus untuk akses terkontrol)
    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public void takeDamage(int damage) {
        this.health -= damage;
        if (this.health < 0) this.health = 0;
        System.out.println(this.name + " menerima " + damage + " damage! Sisa HP: " + this.health);
        if (this.health <= 0) {
            System.out.println("💀 " + this.name + " telah tumbang!");
        }
    }
}