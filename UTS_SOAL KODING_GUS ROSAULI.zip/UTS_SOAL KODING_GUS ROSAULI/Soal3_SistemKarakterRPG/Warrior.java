// Warrior.java
// Class Warrior, mewarisi Character dan mengimplementasikan Skill.
public non-sealed class Warrior extends Character implements Skill {
    private int armor; // Atribut spesifik Warrior

    public Warrior(String name, int health, int attackPower, int armor) {
        super(name, health, attackPower); // Constructor Chaining
        this.armor = armor;
    }

    @Override
    public void performAttack(Character target) {
        int damage = attackPower + (armor / 2); // Damage disesuaikan dengan armor
        System.out.println("⚔️ " + name + " mengayunkan pedang perkasa ke " + target.getName() + "!");
        target.takeDamage(damage);
    }

    @Override
    public void activateSkill(Character target) {
        System.out.println("🛡️ " + name + " mengaktifkan skill 'Iron Skin'! Armor meningkat!");
        this.armor += 10;
        System.out.println("Armor " + name + " sekarang: " + this.armor);
    }

    @Override
    public void displayStats() {
        System.out.println("--- Status Warrior ---");
        System.out.println("Nama   : " + name);
        System.out.println("HP     : " + health);
        System.out.println("ATK    : " + attackPower);
        System.out.println("Armor  : " + armor);
    }
}
