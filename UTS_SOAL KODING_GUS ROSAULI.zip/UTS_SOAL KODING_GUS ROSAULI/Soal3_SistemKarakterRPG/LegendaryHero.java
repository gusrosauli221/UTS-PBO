// LegendaryHero.java (Membutuhkan Java 17+)
// Ini adalah class abstrak yang di-sealed. Hanya class yang diizinkan (permits) yang bisa mewarisinya.
// Ini mewakili tipe karakter Heroik yang sangat spesifik dan terbatas.
public abstract sealed class LegendaryHero extends Character
    permits LegendaryKnight { // Hanya LegendaryKnight yang diizinkan mewarisi LegendaryHero
    
    // Atribut umum untuk hero legendaris
    protected String legendaryTitle;

    public LegendaryHero(String name, int health, int attackPower, String title) {
        super(name, health, attackPower);
        this.legendaryTitle = title;
        System.out.println("🌟 Seorang " + title + " bernama " + name + " telah bangkit!");
    }

    // Abstract method khusus untuk hero legendaris
    public abstract void unleashUltimate(Character target);
}
