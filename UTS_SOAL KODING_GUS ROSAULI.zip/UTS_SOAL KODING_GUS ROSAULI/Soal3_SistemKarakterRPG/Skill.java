// Skill.java
// Interface ini mendefinisikan kontrak untuk kemampuan unik yang bisa dimiliki karakter.
public interface Skill {
    // Method untuk mengaktifkan skill.
    // Class yang mengimplementasikan interface ini WAJIB menyediakan logika skill-nya.
    void activateSkill(Character target);
}
