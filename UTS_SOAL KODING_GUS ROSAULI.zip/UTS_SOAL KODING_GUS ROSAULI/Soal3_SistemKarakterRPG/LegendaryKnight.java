// LegendaryKnight.java (Membutuhkan Java 17+)
// Ini adalah subclass eksklusif dari LegendaryHero (karena di-sealed).
// Dibuat sebagai SINGLETON untuk memastikan HANYA ADA SATU INSTANSI di seluruh game.
public final class LegendaryKnight extends LegendaryHero implements Skill {
    private static LegendaryKnight instance; // Instance tunggal (Singleton)
    private int legendaryAura;

    // Konstruktor PRIVATE: Tidak bisa dipanggil dari luar class ini.
    // Ini memastikan objek LegendaryKnight hanya bisa dibuat via getInstance().
    private LegendaryKnight(String name, int health, int attackPower, String title, int legendaryAura) {
        super(name, health, attackPower, title);
        this.legendaryAura = legendaryAura;
        System.out.println("👑 Legendary Knight '" + name + "' dengan Aura " + legendaryAura + " terbentuk!");
    }

    // Metode STATIC untuk mendapatkan instance tunggal LegendaryKnight (Singleton Pattern)
    public static LegendaryKnight getInstance() {
        if (instance == null) {
            // Inisialisasi hanya jika belum ada instance
            instance = new LegendaryKnight("Arthur Pendragon", 500, 70, "Pendragon", 100);
        }
        return instance;
    }

    @Override
    public void performAttack(Character target) {
        int totalDamage = attackPower + legendaryAura;
        System.out.println("✨ " + name + " menebas dengan Excalibur ke " + target.getName() + ", mengeluarkan " + totalDamage + " damage!");
        target.takeDamage(totalDamage);
    }

    @Override
    public void activateSkill(Character target) {
        System.out.println("⚡️ " + name + " mengaktifkan skill 'Divine Protection'! Menerima 50 HP dan menghantam " + target.getName() + "!");
        this.health += 50; // Self-heal
        target.takeDamage(50); // Damage to target
    }

    @Override
    public void unleashUltimate(Character target) {
        System.out.println("🔥 " + name + " melepaskan 'Holy Judgment' pada " + target.getName() + "!");
        target.takeDamage(200); // Ultimate damage
        System.out.println("Langit bergemuruh, keadilan ditegakkan!");
    }

    @Override
    public void displayStats() {
        System.out.println("--- Status Legendary Knight ---");
        System.out.println("Nama           : " + name);
        System.out.println("HP             : " + health);
        System.out.println("ATK            : " + attackPower);
        System.out.println("Aura Legendaris: " + legendaryAura);
        System.out.println("Status         : The One and Only!");
    }
}
