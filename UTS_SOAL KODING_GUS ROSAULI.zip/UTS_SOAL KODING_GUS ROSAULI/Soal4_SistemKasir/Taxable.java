// Taxable.java
// Ini adalah interface yang mendefinisikan kontrak untuk produk yang dikenakan pajak.
// Class yang mengimplementasikan ini harus menyediakan cara menghitung pajaknya.
public interface Taxable {
    // Method untuk menghitung jumlah pajak berdasarkan harga dasar produk.
    double calculateTax(double basePrice);
}