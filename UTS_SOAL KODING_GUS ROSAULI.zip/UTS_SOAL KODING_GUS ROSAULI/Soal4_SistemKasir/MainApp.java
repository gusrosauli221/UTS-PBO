import java.util.ArrayList; // Untuk menggunakan ArrayList sebagai keranjang belanja
import java.util.List;    // Untuk tipe List

// MainApp.java
// Class utama yang berfungsi sebagai sistem kasir sederhana.
public class MainApp {
    public static void main(String[] args) {
        System.out.println("=== Selamat Datang di KASIR PBO CERDAS! ===");
        System.out.println("-------------------------------------------\n");

        // --- DAFTAR PRODUK YANG TERSEDIA ---
        Food mieInstan = new Food("Mie Instan Kuah", 3500, "2025-12-31");
        Beverage softDrink = new Beverage("Minuman Soda", 8000, 0.33);
        Food rotiTawar = new Food("Roti Tawar Gandum", 12000, "2025-06-15");
        Beverage airMineral = new Beverage("Air Mineral 1.5L", 5000, 1.5);
        
        System.out.println("\n-------------------------------------------");
        System.out.println("Memulai Transaksi Baru:");
        System.out.println("-------------------------------------------\n");

        // --- KERANJANG BELANJA (Menggunakan Polymorphism) ---
        // Membuat List yang dapat menampung berbagai jenis Product (Food, Beverage)
        List<Product> shoppingCart = new ArrayList<>();
        shoppingCart.add(mieInstan);
        shoppingCart.add(softDrink);
        shoppingCart.add(rotiTawar);
        shoppingCart.add(airMineral);
        shoppingCart.add(softDrink); // Beli lagi soft drink

        // --- PROSES PERHITUNGAN TOTAL BELANJA ---
        double subTotal = 0;
        double totalTax = 0;
        double grandTotal = 0;

        System.out.println("🧾 Daftar Belanja Anda:");
        System.out.println("-------------------------------------------------");
        System.out.printf("%-25s %8s %8s %8s\n", "Nama Produk", "Harga", "Pajak", "Total");
        System.out.println("-------------------------------------------------");

        // Iterasi melalui setiap produk di keranjang belanja
        for (Product item : shoppingCart) { // Ini adalah kunci Polymorphism!
            double itemBasePrice = item.getBasePrice();
            double itemTax = 0;
            
            // Cek apakah produk tersebut Taxable (bisa dikenakan pajak)
            if (item instanceof Taxable) {
                Taxable taxableItem = (Taxable) item; // Casting ke interface Taxable
                itemTax = taxableItem.calculateTax(itemBasePrice); // Polymorphism dalam perhitungan pajak
            }
            
            double itemTotalPrice = itemBasePrice + itemTax;
            
            subTotal += itemBasePrice;
            totalTax += itemTax;
            grandTotal += itemTotalPrice;

            System.out.printf("%-25s Rp%6.0f Rp%6.0f Rp%6.0f\n", 
                              item.getName(), itemBasePrice, itemTax, itemTotalPrice);
        }
        System.out.println("-------------------------------------------------");

        System.out.println("\n--- RINGKASAN PEMBAYARAN ---");
        System.out.printf("Subtotal          : Rp%10.0f\n", subTotal);
        System.out.printf("Total Pajak       : Rp%10.0f\n", totalTax);
        System.out.printf("GRAND TOTAL       : Rp%10.0f\n", grandTotal);

        System.out.println("\n-------------------------------------------");
        System.out.println("Terima kasih sudah berbelanja di KASIR PBO!");
        System.out.println("=== Selamat Tinggal! ===\n");
    }
}