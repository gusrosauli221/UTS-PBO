// Product.java
// Ini adalah class abstrak yang mendefinisikan konsep dasar sebuah produk di toko.
// Semua item yang dijual akan mewarisi class ini.
public abstract class Product {
    protected String name;  // Nama produk
    protected double price; // Harga dasar per unit produk

    // Konstruktor untuk inisialisasi nama dan harga produk
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
        System.out.println("📦 Produk '" + name + "' terdaftar dengan harga dasar Rp" + String.format("%.0f", price));
    }

    // Getter untuk nama produk (akses terkontrol)
    public String getName() {
        return name;
    }

    // Getter untuk harga dasar produk (akses terkontrol)
    public double getBasePrice() {
        return price;
    }

    // Method non-abstrak: Untuk menampilkan informasi dasar produk
    public void displayProductInfo() {
        System.out.println("Nama Produk: " + name);
        System.out.println("Harga Dasar: Rp" + String.format("%.0f", price));
    }
}