// Beverage.java
// Class Beverage, mewarisi Product dan mengimplementasikan Taxable.
public class Beverage extends Product implements Taxable {
    private double volumeLitres; // Atribut spesifik untuk minuman (dalam liter)
    private static final double BEVERAGE_TAX_RATE = 0.10; // Pajak minuman 10%

    // Konstruktor untuk Beverage, memanggil konstruktor superclass Product
    public Beverage(String name, double price, double volumeLitres) {
        super(name, price); // Constructor Chaining
        this.volumeLitres = volumeLitres;
        System.out.println("🥤 Minuman '" + name + "' " + volumeLitres + "L siap jual.");
    }

    // Implementasi method calculateTax() dari interface Taxable (WAJIB diimplementasikan)
    @Override
    public double calculateTax(double basePrice) {
        return basePrice * BEVERAGE_TAX_RATE;
    }

    // Metode spesifik untuk Beverage (opsional)
    public double getVolumeLitres() {
        return volumeLitres;
    }

    // Override displayProductInfo untuk menambahkan info spesifik Beverage
    @Override
    public void displayProductInfo() {
        super.displayProductInfo(); // Panggil method dari superclass
        System.out.println("Kategori   : Minuman");
        System.out.println("Volume     : " + volumeLitres + " Liter");
        System.out.println("Pajak (%)  : " + (BEVERAGE_TAX_RATE * 100) + "%");
    }
}