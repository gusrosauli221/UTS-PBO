// Food.java
// Class Food, mewarisi Product dan mengimplementasikan Taxable.
public class Food extends Product implements Taxable {
    private String expiryDate; // Atribut spesifik untuk makanan
    private static final double FOOD_TAX_RATE = 0.05; // Pajak makanan 5%

    // Konstruktor untuk Food, memanggil konstruktor superclass Product
    public Food(String name, double price, String expiryDate) {
        super(name, price); // Constructor Chaining
        this.expiryDate = expiryDate;
        System.out.println("🍔 Makanan '" + name + "' dengan expired " + expiryDate + " siap jual.");
    }

    // Implementasi method calculateTax() dari interface Taxable (WAJIB diimplementasikan)
    @Override
    public double calculateTax(double basePrice) {
        return basePrice * FOOD_TAX_RATE;
    }

    // Metode spesifik untuk Food (opsional)
    public String getExpiryDate() {
        return expiryDate;
    }

    // Override displayProductInfo untuk menambahkan info spesifik Food
    @Override
    public void displayProductInfo() {
        super.displayProductInfo(); // Panggil method dari superclass
        System.out.println("Kategori   : Makanan");
        System.out.println("Expired    : " + expiryDate);
        System.out.println("Pajak (%)  : " + (FOOD_TAX_RATE * 100) + "%");
    }
}