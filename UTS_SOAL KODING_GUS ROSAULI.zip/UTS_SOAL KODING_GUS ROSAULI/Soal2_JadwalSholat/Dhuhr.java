// Dhuhr.java
// Class untuk waktu sholat Dzuhur. Mewarisi Prayer dan mengimplementasikan AudioReminder.
public class Dhuhr extends Prayer implements AudioReminder {

    // Konstruktor untuk Dzuhur, memanggil konstruktor superclass Prayer
    public Dhuhr() {
        super("Dzuhur", "Tengah Hari");
    }

    // Override method remind() dari Prayer (WAJIB diimplementasikan)
    @Override
    public void remind() {
        System.out.println("\n--- PENGUMUMAN WAKTU SHOLAT ---");
        System.out.println("☀️ Waktu **Sholat Dzuhur** telah tiba! Segera tinggalkan aktivitas dan tunaikan kewajiban.");
        System.out.println("Waktu " + timeDescription + ".");
    }

    // Implementasi method playAdzan() dari interface AudioReminder (WAJIB diimplementasikan)
    @Override
    public void playAdzan() {
        System.out.println("🔊 Adzan Dzuhur berkumandang: Asyhadu anna Muhammadar Rasulullah...");
    }
}