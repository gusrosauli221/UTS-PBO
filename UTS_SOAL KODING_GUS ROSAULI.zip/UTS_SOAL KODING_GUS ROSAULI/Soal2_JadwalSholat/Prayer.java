// Prayer.java
// Ini adalah class abstrak yang mendefinisikan konsep dasar sebuah waktu sholat.
// Class ini tidak bisa di-instantiate langsung, tapi menjadi blueprint untuk waktu sholat spesifik (Subuh, Dzuhur, dll).
public abstract class Prayer { // <--- Pastikan kurung kurawal buka { ada di sini
    // Atribut umum untuk semua waktu sholat
    protected String name; // Nama waktu sholat (misal: "Shubuh", "Dzuhur")
    protected String timeDescription; // Deskripsi waktu (misal: "pagi buta", "tengah hari")

    // Konstruktor untuk menginisialisasi nama dan deskripsi waktu sholat
    public Prayer(String name, String timeDescription) {
        this.name = name;
        this.timeDescription = timeDescription;
        System.out.println("🕌 Jadwal '" + name + "' terdaftar.");
    }

    // Method abstrak: Setiap waktu sholat harus punya cara untuk "mengingatkan".
    // Implementasinya akan berbeda untuk setiap waktu sholat (Subuh, Dzuhur, dll).
    // Method abstrak tidak punya body, hanya deklarasi.
    public abstract void remind();

    // Method non-abstrak: Perilaku umum yang dimiliki semua waktu sholat
    public void displayPrayerInfo() {
        System.out.println("--- Info Sholat ---");
        System.out.println("Nama Sholat : " + name);
        System.out.println("Waktu       : " + timeDescription);
    }
}