// AudioReminder.java
// Ini adalah interface yang mendefinisikan kontrak untuk fitur pengingat audio (adzan).
// Interface hanya berisi deklarasi method, tanpa implementasi.
public interface AudioReminder {
    // Method untuk memutar adzan.
    // Class yang mengimplementasikan interface ini WAJIB menyediakan logika untuk memutar adzan.
    void playAdzan();
}