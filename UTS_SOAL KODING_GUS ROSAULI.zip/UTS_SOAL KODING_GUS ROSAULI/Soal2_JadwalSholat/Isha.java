// Isha.java
// Class untuk waktu sholat Isya. Mewarisi Prayer dan mengimplementasikan AudioReminder.
public class Isha extends Prayer implements AudioReminder {

    // Konstruktor untuk Isya, memanggil konstruktor superclass Prayer
    public Isha() {
        super("Isya", "Malam Hari");
    }

    // Override method remind() dari Prayer (WAJIB diimplementasikan)
    @Override
    public void remind() {
        System.out.println("\n--- PENGUMUMAN WAKTU SHOLAT ---");
        System.out.println("🌃 Waktu **Sholat Isya** telah tiba! Akhiri hari dengan ibadah dan istirahat.");
        System.out.println("Waktu " + timeDescription + ".");
    }

    // Implementasi method playAdzan() dari interface AudioReminder (WAJIB diimplementasikan)
    @Override
    public void playAdzan() {
        System.out.println("🔊 Adzan Isya berkumandang: La ilaha illallah...");
    }
}
