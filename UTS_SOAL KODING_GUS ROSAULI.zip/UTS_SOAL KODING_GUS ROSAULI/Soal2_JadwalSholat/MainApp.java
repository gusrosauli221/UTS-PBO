// MainApp.java
// Class utama untuk mendemonstrasikan polymorphism dan penggunaan class/interface dalam jadwal sholat.
public class MainApp {
    public static void main(String[] args) {
        System.out.println("=== Aplikasi Pengingat Waktu Sholat Digital ===");
        System.out.println("----------------------------------------------\n");

        // --- Inisialisasi Waktu Sholat ---
        // Membuat objek untuk setiap waktu sholat, direferensikan sebagai Prayer (Polymorphism)
        Prayer fajr = new Fajr();
        Prayer dhuhr = new Dhuhr();
        Prayer asr = new Asr();
        Prayer maghrib = new Maghrib();
        Prayer isha = new Isha();

        System.out.println("\n----------------------------------------------");
        System.out.println("Simulasi Pengingat Sholat Harian Dimulai:");
        System.out.println("----------------------------------------------");

        // --- Simulasi Pengingat Shubuh ---
        System.out.println("\n[04:45 WIB - Simulasi Waktu Shubuh]");
        fajr.displayPrayerInfo();
        fajr.remind(); // Memanggil remind() dari objek Fajr
        if (fajr instanceof AudioReminder) { // Cek apakah bisa memutar adzan
            ((AudioReminder) fajr).playAdzan(); // Cast ke AudioReminder untuk memanggil playAdzan()
        }

        // --- Simulasi Pengingat Dzuhur ---
        System.out.println("\n[12:00 WIB - Simulasi Waktu Dzuhur]");
        dhuhr.displayPrayerInfo();
        dhuhr.remind(); // Memanggil remind() dari objek Dhuhr
        if (dhuhr instanceof AudioReminder) {
            ((AudioReminder) dhuhr).playAdzan();
        }

        // --- Simulasi Pengingat Ashar ---
        System.out.println("\n[15:30 WIB - Simulasi Waktu Ashar]");
        asr.displayPrayerInfo();
        asr.remind(); // Memanggil remind() dari objek Asr
        if (asr instanceof AudioReminder) {
            ((AudioReminder) asr).playAdzan();
        }

        // --- Simulasi Pengingat Maghrib ---
        System.out.println("\n[18:00 WIB - Simulasi Waktu Maghrib]");
        maghrib.displayPrayerInfo();
        maghrib.remind(); // Memanggil remind() dari objek Maghrib
        if (maghrib instanceof AudioReminder) {
            ((AudioReminder) maghrib).playAdzan();
        }

        // --- Simulasi Pengingat Isya ---
        System.out.println("\n[19:30 WIB - Simulasi Waktu Isya]");
        isha.displayPrayerInfo();
        isha.remind(); // Memanggil remind() dari objek Isha
        if (isha instanceof AudioReminder) {
            ((AudioReminder) isha).playAdzan();
        }

        System.out.println("\n----------------------------------------------");
        System.out.println("=== Simulasi Selesai. Semoga Ibadah Kita Diterima. Aamiin. ===");
    }
}
