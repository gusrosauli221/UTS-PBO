// Maghrib.java
// Class untuk waktu sholat Maghrib. Mewarisi Prayer dan mengimplementasikan AudioReminder.
public class Maghrib extends Prayer implements AudioReminder {

    // Konstruktor untuk Maghrib, memanggil konstruktor superclass Prayer
    public Maghrib() {
        super("Maghrib", "Saat Matahari Terbenam");
    }

    // Override method remind() dari Prayer (WAJIB diimplementasikan)
    @Override
    public void remind() {
        System.out.println("\n--- PENGUMUMAN WAKTU SHOLAT ---");
        System.out.println("🌇 Waktu **Sholat Maghrib** telah tiba! Saatnya berbuka puasa dan bersyukur.");
        System.out.println("Waktu " + timeDescription + ".");
    }

    // Implementasi method playAdzan() dari interface AudioReminder (WAJIB diimplementasikan)
    @Override
    public void playAdzan() {
        System.out.println("🔊 Adzan Maghrib berkumandang: Hayya 'alal falah...");
    }
}
