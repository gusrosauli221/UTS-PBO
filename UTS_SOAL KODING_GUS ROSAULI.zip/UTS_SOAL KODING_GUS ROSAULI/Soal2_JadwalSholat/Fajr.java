// Fajr.java
// Class untuk waktu sholat Shubuh. Mewarisi Prayer dan mengimplementasikan AudioReminder.
public class Fajr extends Prayer implements AudioReminder {

    // Konstruktor untuk Shubuh, memanggil konstruktor superclass Prayer
    public Fajr() {
        super("Shubuh", "Dini Hari (sebelum matahari terbit)");
    }

    // Override method remind() dari Prayer (WAJIB diimplementasikan)
    @Override
    public void remind() {
        System.out.println("\n--- PENGUMUMAN WAKTU SHOLAT ---");
        System.out.println("✨ Waktu **Sholat Shubuh** telah tiba! Mari bersiap menyambut pagi dengan ibadah.");
        System.out.println("Waktu " + timeDescription + ". Bangunlah, wahai jiwa yang mulia!");
    }

    // Implementasi method playAdzan() dari interface AudioReminder (WAJIB diimplementasikan)
    @Override
    public void playAdzan() {
        System.out.println("🔊 Adzan Shubuh berkumandang: Allahu Akbar Allahu Akbar...");
    }
}
